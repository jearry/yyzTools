# Quick start: build a fast file finder from scratch (no build step)

This guide is for module developers. It walks through creating a web app that runs inside the yyzTools main process from scratch — using the SDK sample project `SDK_Sample`, a fast file finder, as the worked example. It covers the page directory, the window host, i18n, asynchronous Native APIs (whole-disk file search), opening files, config persistence, and the template for adding a native method when you need to extend the C++ side.

The sample is **plain JavaScript, zero third-party dependencies, and needs no build step**: no Vite, no Alpine, no FontAwesome. Copy the `Web` and `Modules` directories next to `yyzTools.exe` and it runs.

## 1. Sample layout and deployment

```
sdk/sample/
  Web/                        ← copy into <directory containing yyzTools.exe>\Web\   (merge with the existing Web directory)
    SDK_Sample/               ← self-contained sample; the whole folder is one complete module
      index.html              # page structure (plain DOM, data-i18n marks the text slots)
      filefinder.js           # all the logic: search / open / history / Esc
      filefinder.css          # page styles (all via --zen-* variables, light and dark adapt automatically)
      i18n.js                 # message dictionary (zh_cn / en)
      lib/
        zen_api.js            # the ZenAPI wrapper class (JS binding for the Native API; the only lib dependency)
        window_controls.css   # theme variables (--zen-*) plus window control bar styles
  Modules/                   ← copy into <directory containing yyzTools.exe>\Modules\  (merge with the existing Modules directory)
    SDK_Sample.zenmod         # type:"web" module declaration; ModuleManager creates the host window automatically
```

Deployment:

```text
Copy/merge sdk/sample/Web     into  bin64\Web\
Copy/merge sdk/sample/Modules into  bin64\Modules\
Restart yyzTools.exe and search the command palette for "SDK Sample Project" to launch it
```

Where the main program looks for things:

| Resource | Location                                                   |
| -------- | ---------------------------------------------------------- |
| Pages    | `<exe directory>\Web\{page}\index.html`                     |
| Modules  | `<exe directory>\Modules\<category>\*.zenmod` (one level of subdirectories only) |

## 2. Architecture: how a web app actually runs

```text
Modules/SDK_Sample.zenmod   ← module file declaring type:"web" (data-driven; no C++ required)
        │  scanned by the main program at startup
        ▼
WebModule host window (native window + WebView2)
        │  loads Web\SDK_Sample\index.html
        ▼
Web/SDK_Sample/             ← all of your front-end code (plain JS, zero dependencies)
        │  window.Zen.xxx(...)  ←→  native methods registered by the main program
        ▼
C++ managers (file / process / window / clipboard / OCR ...)
```

Key takeaways:

* **You do not need to write any C++.** A `.zenmod` with `type: "web"` is turned into a WebModule host window automatically; window size, icon, and localized names are all declared in the module file.

* Your module gets these for free: command palette search (including pinyin indexing), global hotkey binding, dock mounting, and registration in the `windowControl` name table.

* `window.Zen` is the only channel between the front end and C++. Always go through the `ZenAPI` wrapper class (the sample ships with `lib/zen_api.js`).

* Build-free pages are plain static files. Edit, refresh the window, and the change is live (`windowControl('sdk_sample','hide')` then show, or restart the exe) — no compilation step at all.

## 3. Page structure (plain JS, four files)

### index.html

No third-party libraries. The three window control buttons use Unicode characters as icons (− / □ / ×), styled by `lib/window_controls.css`. Text slots are marked with `data-i18n` / `data-i18n-ph` and filled in by JS at startup. The structure has four parts: the search bar, search history chips, the status bar (result count plus a syntax hint), and the result list:

```html
<div class="search-bar">
    <input type="text" id="searchInput" class="search-input" data-i18n-ph="inputPlaceholder"
           spellcheck="false" autocomplete="off">
    <button class="search-btn" id="btnSearch" data-i18n="search"></button>
</div>
<div class="history-chips" id="historyChips"> ... </div>
<div class="status-bar">
    <span id="statusText" data-i18n="empty"></span>
    <span class="syntax-hint" data-i18n="syntaxHint"></span>
</div>
<div class="result-list" id="resultList"></div>
```

### filefinder.js (the core logic)

Five responsibilities; copying the sample verbatim is fine:

1. **Window control**: `ZenAPI.windowControl('sdk_sample', 'min'|'max'|'close'|'drag')`. Title bar dragging only fires once the pointer has moved more than 5px. For the Esc key — if the input has focus, blur it first; otherwise close the window.
2. **Theming**: register `window.__applyTheme` to receive pushes from C++ (the initial `data-theme` is injected by C++, so JS does not need to handle first paint).
3. **i18n**: read `getConfig().language`, pull the strings from the dictionary, and walk the `data-i18n` elements to fill them in. Sentences containing `{{count}}` placeholders are expanded by an interpolation helper.
4. **Search**: `searchFile(keyword, maxResults)` is an **async binding** (it runs on a background thread and does not block the UI). Enter searches immediately; typing triggers an automatic search after a 300 ms debounce. An incrementing sequence number discards out-of-order replies — the native side has a search-slot mechanism (a new request displaces any unfinished older one, whose Promise then resolves with an empty result), and the front-end sequence number stops that late-arriving empty result from overwriting freshly rendered results. The two work together.
5. **Acting on results**: `openFile(fullPath, false)` opens a file (same as double-clicking; the second argument is "run as administrator"). `openFileLocation(fullPath)` opens the containing directory. Build the full path with `path + '\\' + name`. Use the `icon` field already present in each result (base64) rather than fetching it again, and format the numeric `size` field for display.

### The shape returned by searchFile (`{ error, files[] }`)

Fields on each entry of `files[]`:

| Field           | Type   | Notes                                                                      |
| --------------- | ------ | -------------------------------------------------------------------------- |
| `name` / `path` | string | File name / containing directory. Full path = `path + '\\' + name`          |
| `dateModified`  | string | Modification time (localized display text)                                  |
| `size`          | number | File size in bytes — **a real number, use it directly**                     |
| `icon`          | string | base64 icon, ready to drop into `<img src>`; no need to call `getFileIcon`  |
| `score`         | number | Relevance score (native has already sorted by it)                           |
| `isDir`         | number | **1/0, not a native boolean** (hand-built JSON path). Test with truthiness or `=== 1`, never `=== true` |

### The APIs this sample uses

| API                               | Binding | Purpose                                                                                     |
| --------------------------------- | ------- | ------------------------------------------------------------------------------------------- |
| `searchFile(keyword, maxResults)` | async   | Whole-disk MFT index search with Everything syntax (`size:>100MB`, `ext:mp4`, `!ext:tmp`)     |
| `openFile(path, admin)`           | sync    | Open a file or directory (shell default action); `admin=true` runs it elevated                |
| `openFileLocation(path)`          | sync    | Reveal the file in Explorer                                                                   |
| `getConfig(key?)`                 | sync    | Read config: everything by default, or just one key (dotted `a.b` paths supported)            |
| `setConfig(patch, replace?)`      | sync    | Write search history **narrowly**: `setConfig({ sdk_sample: { history } })`. `replace=true` replaces wholesale (only for restoring backups) |
| `log(message)`                    | sync    | Front-end logging into the main process log, useful for diagnosis                             |
| `windowControl(name, action)`     | sync    | Minimize / maximize / close / drag the window                                                 |

### Four rules for calling the API

```js
import ZenAPI from './lib/zen_api.js';

// 1. Check for errors with isOk() (error is always a number: 0 on success, -1 on a call exception)
const res = await ZenAPI.searchFile('yyztools', 200);
if (!ZenAPI.isOk(res)) { ... }

// 2. Boolean fields returned by the API are real booleans, so test them directly.
//    (Exception 1: config values are typed by whatever the front end wrote, usually strings —
//     normalize before comparing.)
//    (Exception 2: isDir in searchFile results is a 1/0 number — hand-built JSON path.
//     Use truthiness or === 1.)
const ex = await ZenAPI.exists(path);
if (ex.exists === true) { ... }

// 3. Config writes must be narrow. Never write the whole document back.
await ZenAPI.setConfig({ sdk_sample: { history } });   // touch only your own key

// 4. To fetch app info by id in bulk use getAppInfo; never loop over searchApp.
const infos = await ZenAPI.getAppInfo(['calculator', 'ocr']);
```

The async APIs (`getAppInfo`, `searchFile`, the five media methods, `ocrRecognition`) run on background threads. Note that only one media subprocess runs at a time, so long-running tasks should offer a `cancelRun()` escape hatch.

### Handy APIs beyond this sample

| Scenario                    | API                                                                             |
| --------------------------- | ------------------------------------------------------------------------------- |
| Read/write your own config  | `getConfig` / `setConfig` (narrow patch) / `addConfig` (append a list item)       |
| Open / save files           | `browseFile` / `browseDir` / `writeFile` / `readFile` (use `readFileChunk` above 50 MB) |
| Get a system directory      | `getKnownDir('download')` and friends                                             |
| Open a web page or program  | `runAny('https://...', '')`                                                       |
| Copy to the clipboard       | `navigator.clipboard` in the front end (no native call needed for plain text)     |
| Screenshot / OCR            | `screenCap('fast', ...)` → `ocrRecognition(base64)` (both async)                  |
| Summon another module       | `windowControl('translate', 'show')`                                              |

## 4. Create the .zenmod module file (the window host)

Add a `.zenmod` under `Modules/<category>/` (the sample file is `sdk/sample/Modules/SDK_Sample.zenmod`):

```json
{
    "id": "sdk_sample",
    "type": "web",
    "name": { "zh_cn": "SDK样例工程", "en": "SDK Sample Project", "...": "12 languages in total" },
    "desc": { "zh_cn": "基于 MFT 索引的全盘急速文件搜索，支持 Everything 语法", "en": "..." },
    "icon": "fas fa-search",
    "winClassName": "yyzTools::SdkSampleWindowClass",
    "width": 760,
    "height": 540,
    "layoutType": 34,
    "url": "SDK_Sample/index.html",
    "preCreate": 0
}
```

Field reference (everything the main program reads when `type:"web"`):

| Field          | Required | Notes                                                                                     |
| -------------- | -------- | ----------------------------------------------------------------------------------------- |
| id             | Yes      | Globally unique. Doubles as the window name for `windowControl`/`windowState`, the hotkey `appId`, and the dock mount id |
| type           | Yes      | Always `web`                                                                                |
| name           | Yes      | An object of 12 languages. A plain string also works (suggested for internal testing only); lookup falls back current language → en → plain string |
| desc           | No       | Same as above                                                                               |
| icon           | No       | A FontAwesome class (as above) or a base64 image                                            |
| winClassName   | No       | Win32 window class name; just needs to be globally unique                                   |
| width / height | No       | Initial window size, defaults to 800x600                                                    |
| layoutType     | No       | Bitmask for the initial position; 34 = horizontally centered + vertically centered          |
| url            | Yes      | Page path relative to the Web root (`SDK_Sample/index.html`); an `http(s)` address also works |
| preCreate      | No       | 1 = create the window at startup (faster first open); defaults to 0, created on demand      |
| canSuspend     | No       | 1 = allow the WebView to suspend while the window is hidden to save resources (defaults to 1) |

Check your work: the JSON parses, the file is UTF-8 without BOM, the id is globally unique, and all 12 languages are non-empty.

**Your app is now complete.** Copy the two directories as described in section 1, then search the command palette for "SDK Sample Project" or "sdk" to launch it (the pinyin index is generated automatically). `windowControl('sdk_sample', 'show')` will summon it too.

## 5. Localized strings (the dictionary approach)

For a build-free module a plain ES module dictionary is enough (`i18n.js`):

```js
const messages = {
    zh_cn: { title: 'SDK样例工程', results: '{{count}} 个结果，耗时 {{ms}} ms', ... },
    en:    { title: 'SDK Sample Project', results: '{{count}} results in {{ms}} ms', ... }
};
export function getMessages(lang) { return messages[lang] || messages.en; }
export function interpolate(dict) {
    return (key, params) => { /* {{count}} → params.count */ };
}
```

At startup read `getConfig().language` to pick the language, falling back to `en` when there is no match. Expand sentences containing placeholders with `tf('results', { count, ms })`.

Notes:

* Language codes use the lowercase-underscore style (`zh_cn`), matching `.zenmod`. They are not BCP 47 tags.

* **The `name`/`desc` in a `.zenmod` must cover all 12 languages.** Strings inside your page have no such requirement; the sample only ships zh\_cn/en, extend as needed.

* If your module needs to switch language on the fly, change the dictionary to lazy-load per-language files with `import()`. The mechanism is otherwise identical.

## 6. Debugging and integration

```text
1. Run it build-free (the recommended starting point):
   Copy sdk/sample/Web and sdk/sample/Modules into bin64\ (where the Release exe lives), then restart the exe.
   After editing the front end, call windowControl('sdk_sample','close') and reopen, or restart the exe.

2. Inspect the structure in a browser:
   Just double-click Web/SDK_Sample/index.html to open it in a browser.
   There is no window.Zen in a browser, so ZenAPI.call takes the exception path and returns error: -1.
   Page structure, styles, input debouncing, and render logic can all be debugged normally
   (everything except the native calls).
```

A note on search performance: `searchFile` uses the whole-disk MFT index on the C++ side and typically returns within milliseconds. The native side has a search-slot mechanism — a new request displaces any unfinished older one, which then returns an empty result. Combined with the front end's 300 ms debounce and its incrementing sequence number for discarding out-of-order replies, sustained typing will neither swamp the background thread nor flash stale results. Result icons (base64) come back with `searchFile`, so there is no need for a separate `getFileIcon` call.

When the available APIs are not enough — for example when you need a new C++ capability — file a request through the feedback channel on the website and it can be added to the main program in a later version.

## 7. Minimal example checklist

| Change            | File                                                                             | Required |
| ----------------- | -------------------------------------------------------------------------------- | -------- |
| New page          | `Web/SDK_Sample/` (index.html / filefinder.js / filefinder.css / i18n.js)          | Yes      |
| Shared dependency | `Web/SDK_Sample/lib/` (zen\_api.js / window\_controls.css, bundled with the sample) | Yes      |
| New module        | `Modules/SDK_Sample.zenmod`                                                       | Yes      |
| C++ changes       | None                                                                              | —        |
| Build steps       | None (build-free, copy and run)                                                   | —        |

## 8. Security notice

The Native API gives module developers **unrestricted access** to the host process's system capabilities — reading, writing and deleting files, creating and terminating processes, window control, clipboard access, changing system settings, running command lines, and other **high-risk operations** — with **no permission prompts, no sandbox, and no undo**.

Assess the safety of every operation yourself before you call it: validate all external input, back up or ask the user to confirm before anything irreversible, and use only the capabilities your feature genuinely needs. You assume full responsibility for the consequences.

