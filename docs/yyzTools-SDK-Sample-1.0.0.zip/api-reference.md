# API Reference

## Version history

| Version | Revised by | Revision date | Notes |
| ----- | -------- | ---------- | ---- |
| 1.0.0 | yyzTools | 2026-09-01 | Initial version |

## 1. General conventions

This document defines all APIs related to interacting with the native layer. It covers only the APIs registered by the **main process, yyzTools.exe** (`SetupBindings()` in `src/yyztools/NativeApi.cpp`).

### Calling convention

* The front end calls API functions through the `window.Zen` object. Prefer the `ZenAPI` wrapper class in `web/lib/zen_api.js`; do not access `window.Zen` directly from business code, so that the wrapper can serve as a compatibility layer when APIs change.

* Input: passed as positional arguments; see each API for the exact number and types.

* Output: returned as a JSON object with the following contents

  ```json
  {
      "error": 0,
      "errorMsg": "",
      ...
  }
  ```

  * error: 0 for success, non-zero for failure

  * errorMsg (optional): error message

  * Others (optional): see each API

### Error checking

`error` is always a **number**: 0 for success, non-zero for failure (-1 when the call itself throws).

### Synchronous / asynchronous bindings

Most APIs use synchronous bindings (`BindSync`) and return immediately. The following 7 APIs use asynchronous bindings (`BindAsync`): they run on a background thread and resolve through a Promise, without blocking the UI thread:

`getAppInfo`, `searchFile`, `imageRun`, `ffmpegRun`, `pdfRun`, `gsRun`, `ocrRecognition`

For constraints on concurrent behavior, see the individual entries (for example, the five media APIs run serially and share `cancelRun` for cancellation).

## 2. Common APIs

### 2.1 Get client version

```ts
function Zen.getVersion() : object
```

* Input: none

* Output

  ```json
  {
      "error": 0,
      "errorMsg": "",
      "apiVersion": "1.0.1",
      "appVersion": "1.0.1",
      "usageTime": 90,
      "usageTimes": 3602,
      "firstUseTime": "20250910"
  }
  ```

  * apiVersion: client API version. The version number is incremented by 1 on every API update; digits run from 0 to 9 and roll over after 9, e.g. 1.0.0, 1.0.1, 1.0.2 ... 1.0.9, 1.1.0, and so on

  * appVersion: client version

  * usageTime: usage time (unit: s)

  * usageTimes: number of activations

  * firstUseTime: time of first use, in `yyyymmdd` format

### 2.2 Get configuration

```ts
function Zen.getConfig(key?: string) : object
```

* Input

  * key (optional): retrieve only this key; dot paths such as `a.b` are supported. Omit it to return the full configuration.

    * Hit: returns `{"error":0, "<key>": <value>}`, e.g. `getConfig("language")` → `{"error":0,"language":"zh_cn"}`; `getConfig("dock.categories")` → `{"error":0,"dock":{"categories":[...]}}`

    * Miss: returns `{"error":0}` (not an error; the caller supplies its own fallback)

* Output (example; actual fields depend on the configuration)

  ```json
  {
      "error": 0,
      "errorMsg": "",
      "logLevel": "1",
      "wallpaperEnabled": "1",
      "overlayEnabled": "0",
      "gameMode": "0",
      "clipboardHistoryMaxCount": "500",
      "autoStart": "1",
      "shortcutKeys": {
          "main": {
              "doubleCtrlEnabled": "1",
              "doubleAltEnabled": "1",
              "modifier": 1,
              "virtualCode": 32
          },
          "apps": [
              {
                  "appId": "translate",
                  "modifier": 1,
                  "virtualCode": 49
              },
              {
                  "appId": "ocr",
                  "modifier": 1,
                  "virtualCode": 50
              }
          ]
      },
      "quickOpen": [
          {
              "name": "谷歌搜索",
              "type": "normal",
              "index": "0",
              "url": "https://www.google.com/search?q={query}",
              "enabled": "1"
          }
      ],
      "customApps": [
          {
              "filePath": "d:\test\test1.exe",
              "enabled": "1"
          }
      ]
  }
  ```

  * logLevel: log level (0: Trace / 1: Debug / 2: Info / 3: Warning / 4: Error / 5: Fatal)

  * wallpaperEnabled: enable dynamic wallpaper

  * overlayEnabled: enable desktop effects

  * gameMode: game mode

  * clipboardHistoryMaxCount: maximum number of clipboard history entries

  * autoStart: start on boot

  * shortcutKeys: global shortcut keys

    * main: main window

      * doubleCtrlEnabled: wake with double-tap Ctrl

      * doubleAltEnabled: wake with double-tap Alt

      * modifier: modifier key

      * virtualCode: main key

    * apps: applications

      * appId: application id

      * modifier: modifier key

      * virtualCode: main key

  * quickOpen: quick open

    * name: name

    * type: type (normal: general search / spec: vertical search)

    * index: ordinal

    * url: URL template

    * enabled: whether enabled

  * customApps: custom apps

    * filePath: path to the app's executable

    * enabled: whether enabled

  * dock: dock (categories + contents)

    * **General convention: the absence of** **`name`/`icon`** **means "use the built-in default" (derived at runtime from i18n or from the** **`.zenmod`** **matching** **`appId`**, **and it follows the interface language); the presence of the field means the user has customized it, and it is displayed as-is without translation.**

    * categories: categories

      * id: built-in categories use semantic ids (`folder`/`tools`/`ai`/`game`/`system`); user-created ones use `category_<timestamp>`

      * name: optional; present only after the user renames it

      * icon: FontAwesome class

      * color: theme color

      * order: sort ordinal

    * contents: content items

      * id: built-in directory items use semantic ids (`desktop`/`documents`/`downloads`/`music`/`videos`); others use `content_<timestamp>`

      * categoryId: id of the owning category

      * type: `app` | `folder` | `url`

      * appId: required when `type=app`; the id of the corresponding `.zenmod`. Name and icon are both derived from it — **do not persist them**

      * folderPath: required when `type=folder`; environment variables such as `%USERPROFILE%` are supported

      * url: required when `type=url`; the normalized full address (`https://` is prepended automatically when no protocol prefix is present). Clicking opens it in the system default browser. The name is entered by the user; the icon is the site favicon fetched at runtime (falling back to `fas fa-globe` on failure) and is **not persisted**

      * name / icon: optional, with the same semantics as above (required for user-selected directories with `type=folder`)

      * color: icon tint

      * order: sort ordinal within the category

### 2.3 Modify configuration

```ts
function Zen.setConfig(config: json_obj, replace?: boolean) : object
```

* Input

  * config: same as getConfig

    * Pass only what you are changing; there is no need to pass everything

    * Content under the same key must be passed in full

    ```json
    {
        "logLevel": "1"
    }
    ```

  * replace (optional, default false): false = merge incrementally into the existing configuration; true = replace wholesale (for importing backups; this can clear list items that were deleted). Pass the string `"true"` or `"false"`; omitting it is equivalent to `"false"`.

* Note: **do not "read the full configuration with getConfig and write it all back with setConfig"** — the return value of `getConfig` carries an `error` field, and writing the whole thing back would store it in the configuration file. Always write at a narrow granularity, e.g. `setConfig({ dock: { categories } })`.

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

### 2.4 Add configuration

```ts
function Zen.addConfig(key: string, value: json_obj) : object
```

* Input

  * key: the value type must be StringList or StringMapList

  * value

    * When the value type of key is StringList, pass a string

    * When the value type of key is StringMapList, pass a json\_obj

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

### 2.5 Get list

```ts
function Zen.getList(type: string) : object
```

* Input

  * type: list type

    * font: system font list (read from the registry key `HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts`, for font selection in scenarios such as watermarking)

* Output

  ```json
  {
      "error": 0,
      "errorMsg": "",
      "list": [
          {
              "name": "Arial",
              "file": "arial.ttf"
          }
      ]
  }
  ```

  * list: font list

    * name: font name (with the " (TrueType)" / " (OpenType)" suffix stripped)

    * file: font file name

### 2.6 Write a front-end log

```ts
function Zen.log(msg: string) : object
```

* Input

  * msg: log content, written to the main process log (InfoMsg)

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

### 2.7 Write the countdown cache

```ts
function Zen.setCountdownCache(data: string) : object
```

Writes the countdown reminder's cached data into memory shared between the main process and the wallpaper process, and immediately notifies the wallpaper process to re-read it (otherwise the wallpaper would not pick it up until its own 30s poll). Intended for reminder / wallpaper integration; ordinary features should not depend on it.

* Input

  * data: the countdown JSON string (the payload defined by the reminder module)

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

## 3. Window control

### 3.1 Search windows

```ts
function Zen.searchWindow(keyword: string, maxResults : number) : object
```

* Input

  * keyword: search keyword

  * maxResults: maximum number of records

* Output

  ```json
  {
      "error": 0,
      "windows": [
          {
              "hwnd": 18811010,
              "processId": 20708,
              "visible": 1,
              "topmost": 0,
              "name": "Native API接口.md - MarkText",
              "className": "Chrome_WidgetWin_1",
              "path": "C:\\Program Files\\MarkText\\MarkText.exe",
              "cmdArgs": "\"C:\\Program Files\\MarkText\\MarkText.exe\" \"D:\\doc\\a.md\"",
              "desc": "MarkText",
              "icon": "data:image/png;base64,",
              "score": 180
          }
      ]
  }
  ```

  * windows: window list

    * hwnd: window handle

    * processId: id of the process that owns the window

    * visible: whether the window is visible

    * topmost: whether the window is always on top

    * name: window name

    * className: window class name

    * path: full path to the process executable

    * cmdArgs: command line the process was started with

    * desc: description

    * icon: window icon, base64 format

    * score: search score

### 3.2 Window control

```ts
function Zen.windowControl(window: string, action: string) : object
```

* Input

  * window: Name, or HWND in string form

    * cmdPlate: launcher

    * translate: Super Translate

    * download: Turbo Download

    * calculator: Super Calculator

    * filePreview: file previewer

    * ocr: OCR

    * quickocr: quick OCR translation overlay window

    * calendar: perpetual calendar

    * appUsage: application usage statistics

    * tray: tray menu

    * overlay: desktop effects

    * setting: settings

    * main: main window (equivalent to cmdPlate)

  * action

    * show: show and activate

    * showNoActivate: show without activating

    * min: minimize

    * max: maximize

    * restore: restore

    * hide: hide

    * close: close

    * darg: drag

    * topmost: pin on top

    * noTopmost: unpin from top

    * quit: quit the application

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

### 3.3 Show a context menu

```ts
function Zen.showContextMenu(items: object[], x: number, y: number, window: string, width: number, height: number) : Promise<object>
```

* Input

  * items: menu item array, each `{ "id": "delete", "label": "Delete", "icon": "fas fa-trash" }` (icon is a Font Awesome class name)

  * x / y: anchor coordinates (CSS pixels inside the calling page, usually `event.clientX/clientY`)

  * window: calling window name (see Window control), used for coordinate conversion

  * width / height: menu window size (CSS pixels, computed exactly by the caller from item count and longest label; the menu page does not scroll)

* Notes: the menu opens in a standalone native window (WinMenu), free from page bounds, flips automatically at screen edges, and closes automatically on focus loss / outside click / Esc. The Promise resolves when the menu closes.

* Output

  ```json
  {
      "error": 0,
      "id": "delete"
  }
  ```

  id is the selected item id; an empty string when cancelled (outside click / focus loss / Esc).

### 3.4 Get window state

```ts
function Zen.windowState(window: string, can_suspend?: boolean) : object
```

* Input

  * window: Name, or HWND in string form; see Window control

  * can\_suspend (optional): whether the window's WebView may be suspended (resource management switch, defaults to false)

* Notes: this method has a side effect — after querying the state, it resumes WebView rendering if the window is in the show/max state, and otherwise suspends the WebView to save resources (suspension only occurs when can\_suspend is true). Pass true when a resident front-end page polls its own state; pass false for ordinary queries.

* Output

  ```json
  {
      "error": 0,
      "errorMsg": "",
      "state": "show",
      "topmost": "0"
  }
  ```

  * state: state (show: displayed normally / min: minimized / max: maximized / close: closed)

  * topmost: whether the window is always on top

### 3.5 Open the command palette and run a search

```ts
function Zen.openCmdPlateWithSearch(command: string) : object
```

* Input

  * command: search command, for example `f path:C:\Users\Documents` (search the specified directory in the file module)

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

* Notes

  * Use this method to open the command palette window and run a search command automatically

  * Commonly used to jump straight to file search from modules such as the dock

  * The command format supports every search syntax that cmdplate supports

## 4. Application management

### 4.1 Search applications

```ts
function Zen.searchApp(keyword: string, maxResults : number) : object
```

* Input

  * keyword: search keyword

  * maxResults: maximum number of records

* Output

  ```json
  {
      "error": 0,
      "errorMsg": "",
      "apps": [
          {
              "id": "Microsoft.WindowsCamera",
              "name": "相机",
              "path": "C:\Program Files\WindowsApps\Microsoft.WindowsCamera",
              "desc": "",
              "icon": "data:image/png;base64,",
              "appType": 1,
              "score": 90
          }
      ]
  }
  ```

  * apps: application list

    * id: unique id of the application, required when launching it

    * name: name

    * desc: description

    * icon: base64 icon

    * appType: application type (0: Win32 application / 1: UWP application / 2: system command / 3: system setting / 4: built-in module)

    * score: search result score

### 4.2 Batch-fetch application info by id (asynchronous)

```ts
function Zen.getAppInfo(appIds: string[]) : object
```

Configuration stores only `appId`; names and icons are always derived at runtime (the `name` in a `.zenmod` is localized, so snapshotting it into the configuration would leave it stale after a language switch). This method exists for exactly that scenario.

⚠️ **Do not replace it with** **`searchApp(appId, 1)`** **in a loop**: every `searchApp` call performs a full scan of the entire application index plus pinyin matching and score-based sorting, spawns two concurrent threads, and returns multiple results carrying base64 icons. The dock and the shortcut keys add up to dozens of appIds, and querying them one by one noticeably slows down startup. This method fetches them all at once, and the native side resolves exact matches through `map::find`.

Internally it waits for the application index to become ready (the index is built by a background thread), so it is an **asynchronous binding**: calls made early during a cold start will not return empty results.

* Input

  * appIds: array of appIds, for example `["calculator", "Microsoft.WindowsCamera"]`

* Output

  The format is identical to `searchApp` (both use the same `BuildAppResult`), except that:

  * Only exact matches are returned; **ids that cannot be found are silently skipped**, so `apps.length` may be smaller than the input length (useful for detecting stale appIds in the configuration)

  * The order follows the input order, and `score` is always 0 (no scoring is performed)

  ```json
  {
      "error": 0,
      "apps": [
          {
              "id": "calculator",
              "name": "超级计算器",
              "path": "calculator",
              "desc": "",
              "icon": "data:image/png;base64,",
              "appType": 4,
              "score": 0
          }
      ]
  }
  ```

### 4.3 Launch an application

```ts
function Zen.launchApp(id: string, admin : bool) : object
```

* Input

  * id: the app's id (the `id` returned by `searchApp` / `getAppInfo`)

  * admin: run as administrator

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

### 4.4 Get usage statistics

```ts
function Zen.getAppUsage(mode: string, startTime: string, stopTime: string, forceSync : bool) : object
```

* Input

  * mode: aggregation type — day, week, month, year

  * startTime: start time, format: yyyymmddhh, example: 2025110300

  * stopTime: end time, format: yyyymmddhh, example: 2025110300

  * forceSync: whether to force a refresh

* Output

  ```json
  {
      "error": 0,
      "usages": [
          {
              "time": "20251104",
              "name": "yyzTools.exe",
              "logo": "data:image/png;base64,",
              "usageTimes": 2,
              "usageTime": 4.172,
              "clickTimes": 4,
              "moveDistance": 105.572357,
              "pressTimes": 0
          }
      ]
  }
  ```

  * usages: usage statistics

    * time: time — day: yyyymmdd, week: yyyyww, month: yyyymm, year: yyyy

    * name: application name

    * logo: application icon

    * usageTimes: number of uses

    * usageTime: usage duration (unit: seconds)

    * clickTimes: number of mouse clicks

    * moveDistance: mouse movement distance (unit: cm)

    * pressTimes: number of key presses

## 5. Process management

### 5.1 Search processes

```ts
function Zen.searchProcess(keyword: string, maxResults: number) : object
```

* Input

  * keyword: search keyword

  * maxResults: maximum number of records

* Output

  ```json
  {
      "error": 0,
      "processes": [
          {
              "id": 1228,
              "name": "msedge.exe",
              "path": "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
              "cmdArgs": "\"C:\\...\\msedge.exe\" --type=renderer",
              "suspend": 0,
              "desc": "Microsoft Edge",
              "icon": "data:image/png;base64,",
              "score": 60
          }
      ]
  }
  ```

  * processes: process list

    * id: process id

    * name: process name

    * path: full path to the process executable

    * cmdArgs: command line the process was started with

    * suspend: whether the process is suspended

    * desc: description

    * icon: process icon, base64 format

    * score: search score

### 5.2 Process control

```ts
function Zen.processControl(processId: number, action: string, admin: bool) : object
```

* Input

  * processId: process ID

  * action: action

    * terminate: terminate

    * suspend: suspend

    * resume: resume

    * restart: restart

  * admin: whether the new process runs as administrator (applies to restart)

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

## 6. File operations

### 6.1 Search files (asynchronous)

```ts
function Zen.searchFile(keyword: string, maxResults : number) : object
```

* Description: the search is performed by the in-house yyzFileSearch service (MFT index + named-pipe IPC) and supports Everything-style query syntax (for example `size:>100MB`, `!ext:mp4`). Results are sorted by relevance. The search runs on a background thread, so this is an **asynchronous binding**.

* Input

  * keyword: search keyword

  * maxResults: maximum number of records

* Output

  ```json
  {
    "error": 0,
    "files": [
      {
        "name": "WinMain.cpp",
        "path": "D:\\WorkCodeup\\yyztools\\src\\yyztools",
        "dateModified": "2025/10/18 14:05:00",
        "icon": "data:image/png;base64,",
        "score": 0,
        "isDir": 0
      }
    ]
  }
  ```

  * files: file list

    * name: file name

    * path: directory containing the file (without the file name); the full path is path + "\\" + name

    * dateModified: modification time

    * icon: file icon, in base64 format

    * score: search relevance score

    * isDir: 1 for a directory, 0 for a file

### 6.2 Open a file

```ts
function Zen.openFile(path: string, admin: bool) : object
```

* Input

  * path: file path

  * admin: open as administrator

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

### 6.3 Open the file location

```ts
function Zen.openFileLocation(path: string) : object
```

* Input

  * path: file path

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

### 6.4 Open the file preview

```ts
function Zen.openFilePreview(path: string) : object
```

* Input

  * path: file path

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

### 6.5 Copy/cut files to the clipboard

```ts
function Zen.copyFilesToClipboard(paths: string[], operation: string) : object
```

Copies or cuts the files themselves to the clipboard (CF\_HDROP), so they can be pasted with Ctrl+V in File Explorer.

* Input

  * paths: array of file paths

  * operation: `copy` | `move`

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

### 6.6 Browse for files

```ts
function Zen.browseFile(filterName: string,
                        filter: string, initDir: string, supportMulti: bool) : object
```

* Input

  * filterName: filter name

  * filter: filter, e.g. '*.html;*.htm'

  * initDir: initial browsing path

  * supportMulti: whether multiple selection is allowed

* Output

  ```json
  {
      "error": 0,
      "errorMsg": "",
      "paths": ["d:\test\1.txt", "d:\test\2.txt"]
  }
  ```

  * paths: list of full paths of the selected files; if the user cancels, `error` is `cancel`

### 6.7 Browse for a directory

```ts
function Zen.browseDir(initDir: string) : object
```

* Input

  * initDir: initial browsing path

* Output

  ```json
  {
      "error": 0,
      "errorMsg": "",
      "path": "d:\test"
  }
  ```

  * path: full path of the selected directory; if the user cancels, `error` is `cancel`

### 6.8 Get a known directory

```ts
function Zen.getKnownDir(type: string) : object
```

* Input

  * type: directory type

    * download: Downloads

    * video: Videos

    * music: Music

    * picture: Pictures

    * document: Documents

    * appDataRoaming: AppData/Roaming

    * appDataLocal: AppData/Local

    * appDir: the application's own directory

* Output

  ```json
  {
      "error": 0,
      "errorMsg": "",
      "path": "D:\Downloads"
  }
  ```

  * path: full path of the directory of the specified type

### 6.9 Save a file

```ts
function Zen.saveFile(filePath: string, data: string, binaryFile: boolean) : object
```

* Input

  * filePath: file path

  * data: file content

    * Text file: the content itself

    * Binary file: the base64 encoding of the content

  * binaryFile: whether this is a binary file

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

### 6.10 Get a file icon

```ts
function Zen.getFileIcon(filePath: string) : object
```

* Input

  * filePath: file path

* Output

  ```json
  {
      "error": 0,
      "errorMsg": "",
      "icon": "data:image/png;base64,"
  }
  ```

  * icon: file icon, base64-encoded

### 6.11 Read a file

```ts
function Zen.readFile(path: string, encoding: string) : object
```

* Input

  * path: file path

  * encoding: encoding mode

    * "utf8": text mode (default)

    * "base64" or "binary": binary mode

* Output

  On success:

  ```json
  {
    "error": 0,
    "data": "文件内容",
    "encoding": "utf8",
    "size": 1024
  }
  ```

  When the file is too large (>50MB):

  ```json
  {
    "error": 3,
    "errorMsg": "file too large, use readFileChunk instead",
    "fileSize": 52428800,
    "chunkSize": 1048576
  }
  ```

### 6.12 Read a large file in chunks

```ts
function Zen.readFileChunk(path: string, offset: number, length: number, encoding: string) : object
```

* Input

  * path: file path

  * offset: starting offset (bytes)

  * length: number of bytes to read (maximum 1MB)

  * encoding: encoding mode (always "base64")

* Output

  ```json
  {
    "error": 0,
    "data": "base64编码的数据",
    "offset": 0,
    "length": 1048576,
    "encoding": "base64"
  }
  ```

### 6.13 Write a file

```ts
function Zen.writeFile(path: string, data: string, binary: boolean) : object
```

* Input

  * path: file path

  * data: file content

    * Text file: the text content

    * Binary file: the base64-encoded content

  * binary: whether to use binary mode

* Output

  ```json
  {
    "error": 0,
    "errorMsg": ""
  }
  ```

### 6.14 Append to a file

```ts
function Zen.appendFile(path: string, data: string, binary: boolean) : object
```

* Input

  * path: file path

  * data: content to append

    * Text file: the text content

    * Binary file: the base64-encoded content

  * binary: whether to use binary mode

* Output

  ```json
  {
    "error": 0,
    "errorMsg": ""
  }
  ```

### 6.15 Rename/move

```ts
function Zen.rename(oldPath: string, newPath: string, overwrite: boolean) : object
```

* Input

  * oldPath: original path

  * newPath: new path

  * overwrite: whether to overwrite an existing file

* Output

  ```json
  {
    "error": 0,
    "errorMsg": ""
  }
  ```

### 6.16 Copy a file

```ts
function Zen.copyFile(source: string, destination: string, overwrite: boolean) : object
```

* Input

  * source: source file path

  * destination: destination file path

  * overwrite: whether to overwrite an existing file

* Output

  ```json
  {
    "error": 0,
    "errorMsg": ""
  }
  ```

### 6.17 Delete a file or directory

```ts
function Zen.deletePath(path: string, useRecycleBin: boolean) : object
```

* Input

  * path: file or directory path

  * useRecycleBin: whether to move the item to the Recycle Bin (when false, it is deleted directly and **cannot be recovered**)

* Description: directories are always deleted recursively (including all of their contents).

* Output

  ```json
  {
    "error": 0,
    "errorMsg": ""
  }
  ```

### 6.18 Create a directory

```ts
function Zen.mkdir(path: string) : object
```

* Input

  * path: directory path

* Output

  ```json
  {
    "error": 0,
    "errorMsg": ""
  }
  ```

### 6.19 Read a directory

```ts
function Zen.readDir(path: string) : object
```

* Input

  * path: directory path

* Output

  ```json
  {
    "error": 0,
    "files": ["file1.txt", "file2.jpg"],
    "directories": ["subdir1", "subdir2"]
  }
  ```

### 6.20 Check whether a path exists

```ts
function Zen.exists(path: string) : object
```

* Input

  * path: file or directory path

* Output

  ```json
  {
    "error": 0,
    "exists": true
  }
  ```

  * exists: a native boolean

### 6.21 Get file information

```ts
function Zen.getFileInfo(path: string) : object
```

* Input

  * path: file or directory path

* Output

  ```json
  {
    "error": 0,
    "path": "D:\\test\\file.txt",
    "name": "file.txt",
    "isDirectory": false,
    "size": 1024,
    "readonly": false,
    "hidden": false,
    "system": false,
    "modifiedTime": "2025-10-19 18:48:29",
    "createdTime": "2025-10-15 10:30:00",
    "extension": ".txt"
  }
  ```

  * isDirectory / readonly / hidden / system: native booleans

## 7. Media processing

The five media tools are executed by the C++ side, which invokes the third-party CLI tools under `bin64\Platform\`. All of them except `ffprobeRun` are **asynchronous bindings** (executed on a background thread, so the UI thread is not blocked); batch processing is serial, with only one child process running at any given time. Use `Zen.cancelRun()` to terminate the current execution (a cancelled call returns `errorMsg: "cancelled"`).

### 7.1 Run a magick command (asynchronous)

```ts
function Zen.imageRun(args: string) : object
```

* Input

  * args: the complete magick command line arguments (excluding magick.exe itself), assembled by the front end. You must quote paths yourself, for example `"D:\\in.jpg" -resize 800x600 "D:\\out.jpg"`

* Output

  ```json
  {
    "error": 0,
    "stdout": "..."
  }
  ```

* Note: the C++ side does not assemble arguments; it only runs `magick.exe <args>` and captures the result. When error is non-zero, errorMsg passes through magick's stderr; stdout is magick's standard output (the result of commands such as identify)

### 7.2 Run an ffmpeg command (asynchronous)

```ts
function Zen.ffmpegRun(args: string) : object
```

* Input

  * args: the complete ffmpeg command line arguments (excluding ffmpeg.exe itself), assembled by the front end. You must quote paths yourself, for example `-i "D:\in.mp4" -vf "scale=1280:720" -c:v libx264 -crf 23 "D:\out.mp4"`

* Output

  ```json
  {
    "error": 0,
    "stdout": "..."
  }
  ```

* Note: the C++ side does not assemble arguments; it only runs `ffmpeg.exe <args>` and captures the result. When error is non-zero, errorMsg passes through ffmpeg's stderr; stdout is ffmpeg's standard output. Video processing takes a long time, so the C++ default timeout is 1800s

### 7.3 Run an ffprobe command (probe metadata, synchronous)

```ts
function Zen.ffprobeRun(args: string) : object
```

* Input

  * args: the complete ffprobe command line arguments (excluding ffprobe.exe itself). Commonly `-v quiet -print_format json -show_format -show_streams "D:\in.mp4"`

* Output

  ```json
  {
    "error": 0,
    "stdout": "{ ...json... }"
  }
  ```

* Note: the C++ side only runs `ffprobe.exe <args>` and returns. stdout is usually JSON, which the front end parses itself. Probing is fast, so this stays a synchronous binding, with a default timeout of 30s

### 7.4 Run a pdfcpu command (asynchronous)

```ts
function Zen.pdfRun(args: string) : object
```

* Input

  * args: the complete pdfcpu command line arguments (excluding pdfcpu.exe itself), assembled by the front end. You must quote paths yourself, for example `merge "D:\out.pdf" "D:\in1.pdf" "D:\in2.pdf" --force`

* Output

  ```json
  {
    "error": 0,
    "stdout": "..."
  }
  ```

* Note: the C++ side does not assemble arguments; it only runs `pdfcpu.exe <args>` and captures the result. When error is non-zero, errorMsg passes through pdfcpu's stderr; stdout is pdfcpu's standard output (the result of commands such as `info -j`). The C++ default timeout is 1800s

### 7.5 Run a Ghostscript command (asynchronous)

```ts
function Zen.gsRun(args: string) : object
```

* Input

  * args: the complete Ghostscript command line arguments (excluding gswin64c.exe itself), assembled by the front end. You must quote paths yourself, for example `-sDEVICE=pdfwrite -dNOPAUSE -dQUIET -dBATCH -dColorImageResolution=150 -sOutputFile="D:\out.pdf" "D:\in.pdf"`

* Output

  ```json
  {
    "error": 0,
    "stdout": "..."
  }
  ```

* Note: the C++ side does not assemble arguments; it only runs `Platform\Ghostscript\gswin64c.exe <args>` and captures the result. When error is non-zero, errorMsg passes through Ghostscript's stderr. The C++ default timeout is 1800s. Currently used for the compression (optimize) step of the PDF tools; all other PDF operations still go through `pdfRun` (pdfcpu)

### 7.6 Cancel the current media child process

```ts
function Zen.cancelRun() : object
```

* Input: none

* Output

  ```json
  {
    "error": 0
  }
  ```

* Note: raises a cancellation signal that terminates the currently running `imageRun`/`ffmpegRun`/`pdfRun`/`gsRun` child process (`TerminateProcess`). The cancelled call returns `{error:2, errorMsg:"cancelled"}`. Batch processing is serial, with only one child process running at any given time.

## 8. Screen capture and OCR

### 8.1 Capture the screen / pin to desktop

```ts
function Zen.screenCap(mode:string, wait:bool, file: string) : object
```

* Input

  * mode: mode

    * normal: regular

    * long: scrolling capture

    * fast: quick capture to the clipboard (no annotation, suitable for OCR)

    * quickocr: OCR and translate immediately after the region is dragged out, with the translation overlaid on screen at the position of the original text (quick OCR translation)

    * pinClipboard: pin the image on the clipboard to the desktop

    * pinFile: pin the image from an image file to the desktop

    * pinArea: capture the given screen region and pin it in place on the desktop (param takes "x,y,w,h" in physical screen pixels)

    * pinWin: capture the client area of the given window and pin it in place on the desktop (param takes a decimal HWND)

  * wait: whether to wait for the capture to complete

  * param: file path (pinFile); region string "x,y,w,h" (pinArea); decimal HWND (pinWin)

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

### 8.2 Initialize OCR

```ts
function Zen.ocrInit(lang: string) : object
```

* Input

  * lang: language

    * zh-CN: Simplified Chinese

    * zh-TW: Traditional Chinese

    * en-US: English

    * ja-JP: Japanese

    * ko-KR: Korean

    * ru-RU: Russian

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

### 8.3 OCR recognition (asynchronous)

```ts
function Zen.ocrRecognition(image: string) : object
```

OCR is a time-consuming operation, so it is an **asynchronous binding** that calls back through a Promise.

* Input

  * image: the image, Base64-encoded

* Output

  ```json
  {
      "error": 0,
      "errorMsg": "",
      "result": {
          "code": 100,
          "data": [
              {
                  "box": [[38, 33], [281, 26], [282, 71], [40, 78]],
                  "score": 0.9605724896703448,
                  "text": "有发热症状患者"
              }
          ]
      }
  }
  ```

  * result: the recognition result

    * code: code, always 100

    * data: the result set

      * box: the position of the text (coordinates of the four corners)

      * text: the recognized text

      * score: the recognition score

## 9. Encryption and decryption

### 9.1 Encrypt data

```ts
function Zen.encrypt(target: string, algorithm: string, type: string, key: string, iv: string) : object
```

* Input

  * target: the data to encrypt

    * a text string when type="text"

    * Base64-encoded binary data when type="data"

    * a hexadecimal string when type="hex"

    * a file path when type="file"

  * algorithm: the encryption algorithm

    * Symmetric encryption: "aes-128-cbc", "aes-192-cbc", "aes-256-cbc", "aes-128-ecb", "aes-256-ecb", "aes-128-ctr", "aes-256-ctr", "des-cbc", "des-ecb", "des-ede3-cbc" (3DES), "des-ede3-ecb", "rc4", "bf-ecb" (Blowfish), "rc2-cbc", "sm4-cbc", "sm4-ecb", "sm4-ctr"

    * Asymmetric encryption: "rsa-pkcs1", "rsa-oaep" (RSA; encrypt with the public key, decrypt with the private key), "sm2" (the Chinese national standard elliptic curve sm2p256v1; encrypt with the public key, decrypt with the private key; handles input of any length in a single call, no chunking required)

    * key/iv are Base64; they are converted to hexadecimal internally and passed in the form `enc -K <hex> -iv <hex>`, so the key length must match the algorithm exactly

  * type: the input type (defaults to "text")

    * "text": text data

    * "data": Base64-encoded binary data

    * "hex": a hexadecimal string

    * "file": a file path

  * key: for symmetric algorithms, a Base64-encoded key; for asymmetric algorithms (rsa-\*, sm2), PEM text (pass the public key to encrypt and the private key to decrypt; passed through verbatim without Base64 decoding)

  * iv: a Base64-encoded initialization vector (optional, required by some algorithms; ignored for asymmetric algorithms)

* Output

  ```json
  {
    "error": 0,
    "result": "Base64编码的加密数据",
    "algorithm": "aes-256-cbc",
    "type": "text",
    "inputSize": 1024,
    "outputSize": 1040
  }
  ```

### 9.2 Decrypt data

```ts
function Zen.decrypt(target: string, algorithm: string, type: string, key: string, iv: string) : object
```

* Input

  * target: the data to decrypt

    * Base64-encoded ciphertext when type="data"

    * the path to a ciphertext file when type="file"

  * algorithm: the encryption algorithm (same as encrypt)

  * type: the input type (defaults to "data")

    * "data": Base64-encoded ciphertext

    * "file": the path to a ciphertext file

  * key: for symmetric algorithms, a Base64-encoded key; for asymmetric algorithms (rsa-\*, sm2), PEM text (pass the public key to encrypt and the private key to decrypt; passed through verbatim without Base64 decoding)

  * iv: a Base64-encoded initialization vector (optional; ignored for asymmetric algorithms)

* Output

  ```json
  {
    "error": 0,
    "result": "Base64编码的解密数据",
    "algorithm": "aes-256-cbc",
    "type": "data",
    "inputSize": 1040,
    "outputSize": 1024
  }
  ```

### 9.3 Generate a key

```ts
function Zen.generateKey(algorithm: string, bits: string = '') : object
```

A unified entry point for key generation (generated by the bundled openssl.exe; the front end does not need to rely on the browser's WebCrypto).

* Input

  * algorithm: the algorithm name

    * Symmetric: aes-128-cbc / aes-256-cbc / des-cbc / des-ede3-cbc / sm4-cbc / sm4-ecb / sm4-ctr / rc2-cbc / rc4 / bf-ecb, and so on (the key length is derived from the algorithm name)

    * Asymmetric: "rsa" (bits applies) / "sm2" (fixed curve sm2p256v1)

  * bits: the RSA key size ("2048"/"4096", defaults to 2048); ignored for symmetric algorithms and SM2

* Output

  ```json
  // 对称算法
  { "error": 0, "algorithm": "aes-256-cbc", "key": "Base64编码的密钥" }
  // 非对称算法
  { "error": 0, "algorithm": "sm2", "publicKey": "-----BEGIN PUBLIC KEY-----\n...\n-----END PUBLIC KEY-----\n", "privateKey": "-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n" }
  ```

### 9.4 Generate an IV

```ts
function Zen.generateIv(algorithm: string) : object
```

Generates a random IV sized to the block size of the symmetric algorithm (generated by the bundled openssl.exe).

* Input

  * algorithm: the symmetric algorithm name (same list of symmetric algorithms as encrypt)

* Output

  ```json
  { "error": 0, "algorithm": "aes-256-cbc", "iv": "Base64编码的IV" }
  ```

  Note: the AES/SM4 block size is 16 bytes; DES/3DES/RC2 is 8 bytes. ECB mode and the stream cipher (rc4) do not require an IV, and `iv` returns an empty string.

### 9.5 Compute a hash

```ts
function Zen.calcHash(target: string, algorithm: string, type?: string, key?: string) : object
```

* Input

  * target: the target to hash; its meaning depends on type

    * When type="file", a file path

    * When type="text", a text string (the digest is computed over its UTF-8 bytes)

    * When type="data", Base64-encoded binary data

    * When type="hex", a hexadecimal string

  * algorithm: hash algorithm

    * "md5"

    * "sha1"

    * "sha224"

    * "sha256"

    * "sha384"

    * "sha512"

    * "ripemd160"

    * "sm3" (Chinese national standard SM3 digest, 256-bit / 64 hexadecimal characters)

    * "sha3-224" / "sha3-256" / "sha3-384" / "sha3-512" (SHA-3 / Keccak, NIST FIPS 202)

    * "blake2b512" / "blake2s256" (BLAKE2, modern high-performance digests)

    * "crc32" (CRC32 checksum, 8 hexadecimal characters)

    * "crc16" (CRC16 checksum, 4 hexadecimal characters)

    * "checksum" (byte sum, 8 hexadecimal characters)

    * "hmac-md5" / "hmac-sha1" / "hmac-sha256" / "hmac-sha512" / "hmac-sm3" / "hmac-sha3-256" / "hmac-sha3-512" (HMAC; the fourth parameter key is the secret key, and the MAC is returned in hexadecimal)

  * type: input type (optional, defaults to "file")

    * "file": hash a file

    * "text": hash a text string

    * "data": hash binary data (target must be a Base64 string)

    * "hex": hash a hexadecimal string (target is a hex string; it is decoded and hashed byte-wise)

* Output

  ```json
  {
    "error": 0,
    "hash": "D41D8CD98F00B204E9800998ECF8427E",
    "algorithm": "md5",
    "type": "file"
  }
  ```

## 10. Clipboard history

### 10.1 Search the clipboard

```ts
function Zen.searchClip(keyword: string, maxResults : number) : object
```

* Input

  * keyword: the search keyword

  * maxResults: the maximum number of records

* Output

  ```json
  {
    "error": 0,
    "clips": [
      {
        "id": "1235642340977",
        "name": "Weixin.exe",
        "text": "文本内容",
        "ocrJson": "{\"code\":100,\"data\":[...]}",
        "dateCreated": "2025-10-19 18:48:29",
        "image": "data:image/png;base64,",
        "score": 0
      },
      {
        "id": "235634234232",
        "name": "MarkText.exe",
        "text": "function",
        "ocrJson": "",
        "dateCreated": "2025-10-19 18:48:21",
        "image": "",
        "score": 0
      }
    ]
  }
  ```

  * clips: the list of clipboard history entries

    * id: the record id, a unique identifier

    * name: the name of the source process the content was copied from

    * text: the text content (when image is not empty, this is the OCR text of the image)

    * image: the image content, in Base64 format

    * dateCreated: the creation date

    * ocrJson: the formatted output of the image OCR

      * box: the position of the text (coordinates of the four corners)

      * text: the recognized text

      * score: the recognition score

      ```json
      {
          "code": 100,
          "data": [
              {
                  "box": [[38, 33], [281, 26], [282, 71], [40, 78]],
                  "score": 0.9605724896703448,
                  "text": "有发热症状患者"
              }
          ]
      }
      ```

### 10.2 Delete a record

```ts
function Zen.deleteClip(id: string) : object
```

* Input

  * id: the record id

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

### 10.3 Clear all records

```ts
function Zen.clearClip() : object
```

* Input: none

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

## 11. Bookmarks

### 11.1 Search bookmarks

```ts
function Zen.searchBookmark(keyword: string, maxResults : number) : object
```

* Input

  * keyword: the search keyword

  * maxResults: the maximum number of records

* Output

  ```json
  {
      "error": 0,
      "bookmarks": [
          {
              "id": "13568723452",
              "name": "DeepSeek | 深度求索",
              "url": "https://www.deepseek.com/",
              "dateAdded": "2018-12-19 21:20:48",
              "dateLastUsed": "2025-05-21 15:04:06",
              "visitCount": 37,
              "score": 80
          }
      ]
  }
  ```

  * bookmarks: the bookmark list

    * id: the unique ID

    * name: the name

    * url: the link

    * dateAdded: the time it was added

    * dateLastUsed: the time it was last used

    * visitCount: the number of times it has been used

    * score: the search score

### 11.2 Open a bookmark

```ts
function Zen.openBookmark(id: string, privacyMode: bool) : object
```

* Input

  * id: the id

  * privacyMode: private browsing mode

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

## 12. Command execution

### 12.1 Run a command line

```ts
function Zen.runCmd(cmd: string, admin : bool) : object
```

Opens a visible command line window with `cmd.exe /k <cmd>` and runs the command (the window stays open).

* Input

  * cmd: the command

  * admin: whether to run as administrator

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

### 12.2 Run an arbitrary program

```ts
function Zen.runAny(cmdExe: string, cmdArgs: string, admin : bool) : object
```

Directly launches any executable or URL (URLs are opened with the system default association, such as the browser).

* Input

  * cmdExe: the command path or URL

  * cmdArgs: the command arguments

  * admin: whether to run as administrator

* Output

  ```json
  {
      "error": 0,
      "errorMsg": ""
  }
  ```

## 13. Updates

Updates are performed by a separate process, `yyzUpdater.exe`; the main process is only responsible for launching it and probing its status.

### 13.1 Check for updates

```ts
function Zen.checkUpdate() : object
```

Launches `yyzUpdater.exe --check-and-apply` (check, download, and apply in one go).

* Input: none

* Output

  ```json
  { "error": 0, "errorMsg": "success" }
  ```

  Note: `error:0` only means the updater was launched successfully; it **does not indicate the result of the update**. Use `getUpdateState` to query whether an update is in progress or ready.

### 13.2 Get the update status

```ts
function Zen.getUpdateState() : object
```

Probes the update status in real time (for tray polling):

* Whether the updater is running → the single-instance mutex `Local\yyzUpdater_SingleInstance`

* Whether an update has been downloaded and is pending application → whether `%APPDATA%\yyzTools\Update\update.ready` exists (if so, the main package version is parsed from it)

* Whether a manual check has finished with no update available → the `%APPDATA%\yyzTools\Update\update.result` marker (**deleted as soon as it is read**)

* Input: none

* Output

  ```json
  { "error": 0, "status": "idle", "version": "", "lastResult": "" }
  ```

  * status: `idle` (no update activity) / `checking` (the updater is running) / `ready` (downloaded and ready to upgrade)

  * version: only set in the `ready` state, containing the new version number pending application (taken from the main package); an empty string otherwise

  * lastResult: only possibly set in the `idle` state, containing the result of the last **manual** check (`--check-and-apply`): `uptodate` (already up to date) / `error` (the check failed); an empty string when no marker is present. The marker is written by the updater and deleted immediately after this API reads it, so it is **returned only once**, allowing the front end to show a single toast. A silent `--check` does not write the marker and therefore causes no interruption.

  * Status priority: `checking` > `ready` > `idle`

### 13.3 Apply a downloaded update

```ts
function Zen.applyUpdate() : object
```

Launches `yyzUpdater.exe --apply`: read `update.ready` → wait for the main process to exit → replace the files → restart the main process. Only call this when `getUpdateState` returns `ready`.

* Input: none

* Output

  ```json
  { "error": 0, "errorMsg": "success" }
  ```

---

> ## ⚠️ Security notice
>
> The Native API grants module developers **full access** to the host process's system capabilities, including **high-risk operations** such as reading, writing and deleting files, creating and terminating processes, controlling windows, reading and writing the clipboard, modifying the registry and system settings, downloading over the network, and executing command lines.
>
> These APIs have **no permission prompts, no sandbox isolation, and no undo mechanism** — a call takes effect immediately with the current user's privileges, and misuse may cause permanent data loss or system failure.
>
> Please therefore keep the following in mind:
>
> * **Assess safety yourself**: before calling any API, confirm that its arguments (especially paths, process names, and command lines) come from a trusted source and have been thoroughly validated. For irreversible operations such as deleting, overwriting, or terminating processes, back up first or ask the user to confirm.
> * **Beware of untrusted input**: never splice user input, network responses, or third-party data directly into API arguments without validation; guard against path traversal and command injection.
> * **Principle of least privilege**: request only the capabilities your feature actually needs, and avoid reaching for a broader-impact API just because it is convenient.
> * **Use at your own risk**: developers assume all consequences arising from use of this API, including but not limited to data loss, system damage, and security risks.
