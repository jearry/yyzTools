/**
 * i18n.js — Message dictionary for the yyzTools SDK sample (quick file finder).
 * Zero-dependency approach: a plain ES module dictionary, resolved against
 * config.language at init time.
 *
 * Copyright (c) 2026 yyzTools. All rights reserved.
 *
 * Version: 1.0.0
 * Language codes match .zenmod (underscore lowercase style, e.g. zh_cn).
 * Only zh_cn/en are demonstrated here; extend as needed.
 */

const messages = {
    zh_cn: {
        title: 'SDK样例工程',
        inputPlaceholder: '输入关键字搜索全盘文件，如 yyztools 或 size:>100MB',
        search: '搜索',
        history: '最近搜索：',
        clearHistory: '清空',
        empty: '等待搜索...',
        searching: '搜索中...',
        results: '{{count}} 个结果，耗时 {{ms}} ms',
        noResults: '无匹配结果',
        errorPrefix: '搜索失败：{{msg}}',
        syntaxHint: '支持 Everything 语法：size:>100MB、ext:mp4、!ext:tmp 等',
        openFile: '打开',
        openLocation: '打开所在位置',
        dirBadge: '目录',
        minimize: '最小化',
        maximize: '最大化',
        restore: '还原',
        close: '关闭'
    },
    en: {
        title: 'SDK Sample Project',
        inputPlaceholder: 'Search all files, e.g. yyztools or size:>100MB',
        search: 'Search',
        history: 'Recent: ',
        clearHistory: 'Clear',
        empty: 'Waiting for search...',
        searching: 'Searching...',
        results: '{{count}} results in {{ms}} ms',
        noResults: 'No matches',
        errorPrefix: 'Search failed: {{msg}}',
        syntaxHint: 'Everything syntax supported: size:>100MB, ext:mp4, !ext:tmp ...',
        openFile: 'Open',
        openLocation: 'Open location',
        dirBadge: 'DIR',
        minimize: 'Minimize',
        maximize: 'Maximize',
        restore: 'Restore',
        close: 'Close'
    }
};

const FALLBACK_LANG = 'en';

/** Get the message dictionary for a language (falls back to en when missing). */
export function getMessages(lang) {
    return messages[lang] || messages[FALLBACK_LANG];
}

/** Given a dictionary, return an interpolator: tf('results', { count: 10, ms: 35 }). */
export function interpolate(dict) {
    return (key, params) => {
        let s = dict[key] || '';
        for (const [k, v] of Object.entries(params || {})) {
            s = s.replaceAll(`{{${k}}}`, v);
        }
        return s;
    };
}
