/**
 * filefinder.js — Core logic of the yyzTools SDK sample (id: sdk_sample),
 * a quick file finder built with plain JS and zero dependencies.
 * It demonstrates typical usage of the Native API:
 *   async full-disk search (searchFile, Everything-style syntax) /
 *   opening files (openFile) / revealing in Explorer (openFileLocation) /
 *   config read-write (getConfig/setConfig, narrow-granularity history saving) /
 *   frontend logging (log) / window control (windowControl).
 *
 * Copyright (c) 2026 yyzTools. All rights reserved.
 *
 * Version: 1.0.0
 */

import ZenAPI from './lib/zen_api.js';
import { getMessages, interpolate } from './i18n.js';

const MAX_RESULTS = 200;      // max results per search
const HISTORY_MAX = 10;       // recent searches kept
const DEBOUNCE_MS = 300;      // input debounce

const els = {
    title: document.getElementById('winTitle'),
    titlebar: document.getElementById('titlebar'),
    winButtons: document.getElementById('winButtons'),
    input: document.getElementById('searchInput'),
    btnSearch: document.getElementById('btnSearch'),
    status: document.getElementById('statusText'),
    list: document.getElementById('resultList'),
    chips: document.getElementById('historyChips'),
    chipsList: document.getElementById('chipsList'),
    btnClearHistory: document.getElementById('btnClearHistory'),
    btnMin: document.getElementById('btnMin'),
    btnMax: document.getElementById('btnMax'),
    btnClose: document.getElementById('btnClose')
};

let history = [];        // search history: [{ keyword, time }]
let msg = getMessages('en');
let tf = interpolate(msg);
let searchSeq = 0;       // guard against out-of-order responses: only the latest search counts
let isMaximized = false; // maximized state (kept in sync via C++ push-back)

// ==================== i18n: fill text into elements with data-i18n attributes ====================
// data-i18n → textContent; data-i18n-ph → placeholder; data-i18n-title → title (tooltip)
function applyI18n() {
    document.title = msg.title;
    els.title.textContent = msg.title;
    for (const el of document.querySelectorAll('[data-i18n]')) {
        el.textContent = msg[el.dataset.i18n] || '';
    }
    for (const el of document.querySelectorAll('[data-i18n-ph]')) {
        el.placeholder = msg[el.dataset.i18nPh] || '';
    }
    for (const el of document.querySelectorAll('[data-i18n-title]')) {
        el.title = msg[el.dataset.i18nTitle] || '';
    }
}

// ==================== Window control bar ====================
// Drag model (three-event structure, same as the main project's window_controls.js):
//   mousedown records the start point → mousemove immediately triggers one drag
//   (C++ enters a modal move loop until the mouse is released) → mouseup with
//   movement >5px fires a final fallback drag.
// Events are bound on the whole titlebar; the button area stopPropagation prevents misfires.
function bindWindowControls() {
    // C++ pushes the maximized state back on window resize (via ExecuteScript)
    window.__winMaximizedChange = (v) => {
        isMaximized = !!v;
        els.btnMax.title = isMaximized ? msg.restore : msg.maximize;
    };

    let dragging = false;
    let startX = 0, startY = 0;

    els.titlebar.addEventListener('mousedown', (e) => {
        dragging = false;
        startX = e.screenX;
        startY = e.screenY;
    });
    els.titlebar.addEventListener('mousemove', () => {
        if (!dragging) {
            dragging = true;
            ZenAPI.windowControl('sdk_sample', 'drag');
        }
    });
    els.titlebar.addEventListener('mouseup', (e) => {
        const moved = Math.abs(e.screenX - startX) > 5 || Math.abs(e.screenY - startY) > 5;
        if (!dragging && moved) {
            ZenAPI.windowControl('sdk_sample', 'drag');
        }
    });

    // Button area: swallow mousedown/double-click so clicking buttons
    // doesn't trigger dragging/maximizing
    els.winButtons.addEventListener('mousedown', (e) => e.stopPropagation());
    els.winButtons.addEventListener('dblclick', (e) => e.stopPropagation());

    // Double-click on the titlebar toggles maximize (same as the main project)
    els.titlebar.addEventListener('dblclick', () => {
        ZenAPI.windowControl('sdk_sample', isMaximized ? 'restore' : 'max');
    });

    els.btnMin.addEventListener('click', () => ZenAPI.windowControl('sdk_sample', 'min'));
    els.btnMax.addEventListener('click', () => {
        ZenAPI.windowControl('sdk_sample', isMaximized ? 'restore' : 'max');
    });
    els.btnClose.addEventListener('click', () => ZenAPI.windowControl('sdk_sample', 'close'));

    // Esc: blur the input if focused, otherwise close the window
    // (aligned with the main project's EscHandler behavior)
    document.addEventListener('keydown', async (e) => {
        if (e.keyCode !== 27) return;
        if (document.activeElement === els.input) {
            els.input.blur();
            return;
        }
        await ZenAPI.windowControl('sdk_sample', 'close');
    });
}

// ==================== Utilities ====================
// size is a typed native number (hand-built JSON output of BuildFileResult),
// format it numerically
function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    const units = ['KB', 'MB', 'GB', 'TB'];
    let v = bytes, i = -1;
    do { v /= 1024; i++; } while (v >= 1024 && i < units.length - 1);
    return v.toFixed(v >= 100 ? 0 : 1) + ' ' + units[i];
}

// ==================== Search (searchFile, async binding) ====================
async function search(keyword) {
    keyword = keyword.trim();
    if (!keyword) return;

    const seq = ++searchSeq;
    els.status.textContent = msg.searching;

    const t0 = performance.now();
    // Async API: runs on a background thread and resolves via Promise,
    // never blocking the UI thread
    const res = await ZenAPI.searchFile(keyword, MAX_RESULTS);
    if (seq !== searchSeq) return;   // superseded by a newer search, drop it

    if (!ZenAPI.isOk(res)) {
        els.status.textContent = tf('errorPrefix', { msg: res.errorMsg || res.error });
        return;
    }

    const ms = Math.round(performance.now() - t0);
    const files = res.files || [];
    els.status.textContent = files.length > 0
        ? tf('results', { count: files.length, ms })
        : msg.noResults;
    renderResults(files);

    // Write a frontend log entry (demonstrates the log API,
    // visible in the main process log)
    ZenAPI.log(`sdk_sample "${keyword}" -> ${files.length} hits, ${ms}ms`);

    saveHistory(keyword);
}

function renderResults(files) {
    els.list.replaceChildren();
    for (const f of files) {
        const full = (f.path || '') + '\\' + f.name;   // full path = path + "\" + name
        const item = document.createElement('div');
        item.className = 'result-item' + (f.isDir ? ' is-dir' : '');

        const icon = document.createElement('span');
        icon.className = 'result-icon';
        if (f.icon) {
            const img = document.createElement('img');
            img.src = f.icon;
            img.alt = '';
            icon.appendChild(img);
        } else {
            icon.textContent = f.isDir ? '\uD83D\uDCC1' : '\uD83D\uDCC4';
        }

        const body = document.createElement('div');
        body.className = 'result-body';
        const nameRow = document.createElement('div');
        nameRow.className = 'result-name';
        nameRow.textContent = f.name;
        if (f.isDir) {
            const badge = document.createElement('span');
            badge.className = 'dir-badge';
            badge.textContent = msg.dirBadge;
            nameRow.appendChild(badge);
        }
        const metaRow = document.createElement('div');
        metaRow.className = 'result-meta';
        // size is a native number, format directly; isDir is a 1/0 number
        // (hand-built JSON) — normalize before truthy checks
        metaRow.textContent = full
            + (f.isDir ? '' : '  ·  ' + formatSize(f.size || 0))
            + (f.dateModified ? '  ·  ' + f.dateModified : '');
        body.append(nameRow, metaRow);

        const actions = document.createElement('div');
        actions.className = 'result-actions';
        const btnOpen = document.createElement('button');
        btnOpen.className = 'row-btn';
        btnOpen.textContent = msg.openFile;
        btnOpen.addEventListener('click', (e) => {
            e.stopPropagation();
            ZenAPI.openFile(full, false);      // double-click goes through it too
        });
        const btnLoc = document.createElement('button');
        btnLoc.className = 'row-btn';
        btnLoc.textContent = msg.openLocation;
        btnLoc.addEventListener('click', (e) => {
            e.stopPropagation();
            ZenAPI.openFileLocation(full);
        });
        actions.append(btnOpen, btnLoc);

        item.append(icon, body, actions);
        // Double-click = open the file
        item.addEventListener('dblclick', () => ZenAPI.openFile(full, false));
        els.list.appendChild(item);
    }
}

// ==================== Search history (narrow-granularity setConfig) ====================
function renderHistory() {
    els.chips.style.display = history.length === 0 ? 'none' : '';
    els.chipsList.replaceChildren();
    for (const h of history) {
        const chip = document.createElement('button');
        chip.className = 'chip';
        chip.textContent = h.keyword;
        chip.title = h.time;
        chip.addEventListener('click', () => {
            els.input.value = h.keyword;
            search(h.keyword);
        });
        els.chipsList.appendChild(chip);
    }
}

async function saveHistory(keyword) {
    history = history.filter(h => h.keyword !== keyword);
    history.unshift({ keyword, time: new Date().toLocaleString() });
    history = history.slice(0, HISTORY_MAX);
    // Write only our own key; never read the full config and write it all back
    await ZenAPI.setConfig({ sdk_sample: { history } });
    renderHistory();
}

async function clearHistory() {
    history = [];
    await ZenAPI.setConfig({ sdk_sample: { history } });
    renderHistory();
}

// ==================== Theme: register the C++ push-back entry ====================
// The initial data-theme is injected by C++; this only handles the dynamic
// push-back when the theme changes.
function initTheme() {
    window.__applyTheme = (mode) => {
        if (mode === 'dark' || mode === 'light') {
            document.documentElement.setAttribute('data-theme', mode);
        }
    };
}

// ==================== Initialization ====================
async function init() {
    initTheme();
    bindWindowControls();

    // Read config: UI language + our own search history
    const config = await ZenAPI.getConfig();
    if (ZenAPI.isOk(config)) {
        msg = getMessages(config.language);
        tf = interpolate(msg);
        if (config.sdk_sample) {
            history = config.sdk_sample.history || [];
        }
    }
    applyI18n();
    renderHistory();

    // Enter searches immediately; typing auto-searches with debounce
    // (search syntax matches the command plate's file module)
    let debounceTimer = 0;
    els.input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            clearTimeout(debounceTimer);
            search(els.input.value);
        }
    });
    els.input.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => search(els.input.value), DEBOUNCE_MS);
    });
    els.btnSearch.addEventListener('click', () => search(els.input.value));
    els.btnClearHistory.addEventListener('click', clearHistory);

    els.input.focus();
}

init();
